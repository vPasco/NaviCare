import 'dart:ui';

// var buttonColor = Color.fromRGBO(47, 201, 254, 1.0);
// var registerColor = Color(0xFFffdfb4);
// var lightColor = Color(0xFFFFC971);
// var freeDelivery = Color(0xFF025939);
// var textColor = Color(0xFFf2ac29);
// var texthint = Color(0xFF666666);
// var passiveFavorite = Color(0xFFD9886A);

var buttonColor = Color.fromRGBO(47, 201, 254, 1.0); //
var registerColor = Color(0xffd5d5d5);
var lightColor = Color(0xff28b9f2);
var freeDelivery = Color.fromRGBO(47, 201, 254, 1.0);
var textColor = Color.fromRGBO(47, 201, 254, 1.0);
var texthint = Color(0xFF666666);
var passiveFavorite = Color.fromRGBO(47, 201, 254, 1.0);
