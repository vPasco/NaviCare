package com.example.foodorderui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
